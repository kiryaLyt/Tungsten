import React from 'react';

import Header from './components/Header/Header';

import Calculator from './components/Calculator/Calculator';

import Story from './components/Story/Story'


import './App.css';

import { BrowserRouter, Route, Routes } from 'react-router-dom';



const App = () => {
  return (
    <BrowserRouter>
      <div className='app-wrapper'>
        < Header/>
        < Story/>
        <Calculator/>
          <div className='app-wrapper-content'>
            <Routes>

              

            </Routes>
          </div>


      </div>




    </BrowserRouter>
  );
}
export default App;
