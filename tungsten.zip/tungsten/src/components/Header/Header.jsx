
import React from "react";
import logo from "../../images/logo2.png";
import s from './Header.module.css';

const Header = () => { 
    return (
        <header className={s.header}>
            
                <div className={s.logo}>   
                    <img src={logo} alt="" />
                </div>
                    <p className={s.tung}>Tungsten</p>
                <nav>
                
                </nav>
                
        </header>
        
    )
}


export default Header;