
import React from "react";

import s from './Story.module.css';

const Story = () => { 
    return (
        <div className={s.story}>

        </div>
    )
}


export default Story;