
import React from "react";

import s from './Calculator.module.css';

const Calculator = () => { 
    return (
        <div className={s.calculator}>

        </div>
    )
}


export default Calculator;